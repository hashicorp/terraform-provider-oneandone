---------------
DOCUMENTATION
---------------

For accessing to your Cloud servers in a secure and encrypted way through
VPN Access SSL, you have to configure the VPN client in the computer from
which you want access to your Cloud Servers.

-------------------------
Installation on Windows:
-------------------------
For installing and configuring the VPN Client in your computer, you have to
perform the following steps:

  1.- Download OpenVPN client from the official page:
      https://openvpn.net/index.php/open-source/downloads.html

  2.- Execute the installer in default path: C:/Program Files/OpenVPN

  3.- Go to VPN section in the left menu.

  4.- Select your desired VPN and click on the link to start downloading VPN
  configuration file.

  5.- Copy these files to the following path: C:/Program Files/OpenVPN/config

  6.- Execute OpenVPN to start the VPN

-----------------------------------------------------------------------------

------------------------
Installation on Linux:
------------------------

For installing and configuring the VPN Client in your computer, you have to
perform the following steps:


Debian and Ubuntu:
-------------------

  1.- Download and install OpenVPN Client. You can use the following
  command:
                 $apt-get install openvpn

  2.- In Cloudpanel, go to VPN section in the left menu.

  3.- Select your desired VPN and click on the link to start downloading VPN
  configuration file.

  4.- Copy the configuration file <vpnID>.ovpn to your installation path in
  your Linux openvpn path. By default /etc/openvpn.


  5.- Start OpenVPN with the following command from default linux root path(./):

                 $openvpn /etc/openvpn/<vpnID>.ovpn

CentOS:
--------

  1.- OpenVPN isn´t available in the default CentOS repository. Then you
  have to install first Enterprise Linux repository.

                 $ yum install epel-release

  2.- Download and install OpenVPN Client. You can use the following
  command:
                 $ yum install openvpn

  3.- In Cloudpanel, go to VPN section in the left menu.

  4.- Select your desired VPN and click on the link to start downloading VPN
  configuration file.

  5.- Copy the configuration file <vpnID>.ovpn to your installation path in
  your Linux openvpn path. By default /etc/openvpn.

  6.- Start OpenVPN with the following command from default linux root path(./):

                 $openvpn /etc/openvpn/<vpnID>.ovpn